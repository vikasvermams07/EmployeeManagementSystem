<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if(!$_SESSION['username']){
    
    redirect('my_controller','refresh');
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash View</title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
    <!--Navigation Bar-->
   <?php 
   $this->load->view('dash/navi/navi_view');

   //list view
   $this->load->view('dash/list_view');
   ?>

   <!--Navigation LIst-->


<div class="container" style="background-color:brown;padding:20px;border-radius:20px">
  <form action="<?php echo base_url()?>employee/employeeinfo" method="post" class="form-group">

  <div class="form-group">
  <label style="color:whitesmoke">Employee Name</label>
  <input type="text" name="e_name" id="" placeholder="Enter Name" class="form-control">
  </div>

  <div class="form-group">
  <label style="color:whitesmoke">Employee Email</label>
  <input type="email" name="e_email" id="" placeholder="Enter Email" class="form-control">
  </div>

  <div class="form-group">
  <label style="color:whitesmoke">Employee Contact Number</label>
  <input type="text" name="e_number" id="" placeholder="Enter Contact Number" class="form-control">
  </div>

  <div class="form-group">
  <label style="color:whitesmoke">Employee Job Title</label>

            <select name="e_job" required class="form-control" >
            <option  value="">-</option>

                <?php
                
                
                $jobname=$this->db->get('jobes');
                
                foreach($jobname->result() as $info){
                ?>
                <option value="<?php echo $info->j_name;?>"><?php echo $info->j_name;?></option>
                <?php } ?>
            </select>
  </div>
  <div class="form-group">
  <input type="submit" name="addemployee" class="btn btn-success btn-sm">
  </div>
  
  </form>
</div>




</body>
</html>