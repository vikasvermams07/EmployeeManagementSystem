<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if(!$_SESSION['username']){
    
    redirect('my_controller','refresh');
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash View</title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
    <!--Navigation Bar-->
   <?php 
   $this->load->view('dash/navi/navi_view');

   //list view
   $this->load->view('dash/list_view');
   ?>

   <!--Navigation LIst-->


<div class="container" style="background-color:brown;">
<table class="table" style="color:white">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Contact</th>
      <th scope="col">Job</th>
    </tr>
  </thead>
  <tbody>
  <?php
  
  $id=$this->uri->segment(3);
  
  $employeeinfo=$this->db->get_where('employee',array('e_id'=>$id));

  foreach($employeeinfo->result() as $info){
  
  ?>
    <tr>
      <th scope="row"><?php echo $info->e_id?></th>
      <td><?php echo $info->e_name?></td>
      <td><?php echo $info->e_email?></td>
      <td><?php echo $info->e_number?></td>
      <td><?php echo $info->e_job?></td>
    </tr>
<?php }?>
  </tbody>
  <tr>
  <td><a href="<?php echo base_url()?>employee/EmployeeUpdate/<?php echo $info->e_id;?>" class="btn btn-warning btn-sm">Edit</a></td>
  </tr>
</table>

</div>



</body>
</html>