<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if(!$_SESSION['username']){
    
    redirect('my_controller','refresh');
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash View</title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
    <!--Navigation Bar-->
   <?php 
   $this->load->view('dash/navi/navi_view');

   //list view
   $this->load->view('dash/list_view');
   ?>

   <!--Navigation LIst-->


<div class="container" style="background-color:brown;padding:20px;border-radius:20px">
  <form action="<?php base_url()?>upload_controller/upload_jobinfo" method="post" class="form-group">
  <div class="form-group">
  <label style="color:whitesmoke">Enter Job Name</label>
  <input type="text" name="j_name" id="" placeholder="Enter job Name" class="form-control">
  </div>

  <div class="form-group">
  <input type="submit" name="upload" class="btn btn-success btn-sm">
  </div>
  </form>
</div>




</body>
</html>