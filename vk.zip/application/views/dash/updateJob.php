<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if(!$_SESSION['username']){
    
    redirect('my_controller','refresh');
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash View</title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
    <!--Navigation Bar-->
   <?php 
   $this->load->view('dash/navi/navi_view');

   //list view
   $this->load->view('dash/list_view');
   ?>

   <!--Navigation LIst-->

   <div class="container" style="background-color:brown;padding:20px;border-radius:20px">
  <form action="<?php echo base_url()?>upload_controller/updatejobsname" method="post" class="form-group">
<?php


$id=$this->uri->segment(3);

$jobname=$this->db->get_where('jobes', array('id'=>$id));

foreach($jobname->result() as $job){

?>

  <div class="form-group">
  <label style="color:whitesmoke">Edit Job Name</label>
  <input type="hidden" name="jid" value="<?php echo $id?>" class="form-control">
  <input type="text" name="update_name" value="<?php echo $job->j_name?>" class="form-control">
  </div>
  

<?php }?>

<div class="form-group">
  <input type="submit" name="update" class="btn btn-success btn-sm">
  </div>
  </form>
</div>

</body>
</html>