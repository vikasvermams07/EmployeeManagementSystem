<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if(!$_SESSION['username']){
    
    redirect('my_controller','refresh');
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash View</title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
    <!--Navigation Bar-->
   <?php 
   $this->load->view('dash/navi/navi_view');

   //list view
   $this->load->view('dash/list_view');
   ?>

   <!--Navigation LIst-->


<div class="container" style="background-color:brown;">
<table class="table" style="color:white">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">job Name</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
  <?php
  
  $jobinfo=$this->db->get('jobes');

  foreach($jobinfo->result() as $jobs){
  
  ?>
    <tr>
      <th scope="row"><?php echo $jobs->id?></th>
      <td><?php echo $jobs->j_name?></td>
      <td><a href="<?php echo base_url()?>upload_controller/updatejobView/<?php echo $jobs->id;?>" class="btn btn-warning btn-sm">Edit</a></td>
      <td><a href="<?php echo base_url()?>upload_controller/deleteJob/<?php echo $jobs->id;?>" class="btn btn-danger btn-sm">Delete</a></td>
    </tr>
<?php }?>
  </tbody>
</table>

</div>



</body>
</html>