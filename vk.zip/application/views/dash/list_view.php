<div class="container" style="margin:100px">
  <div class="row">
    <div class="col-sm">
<ul class="list-group">
  <li class="list-group-item"><b>Employee</b></li>
  <li class="list-group-item"><a href="<?php echo base_url()?>employee/EmployeeView">View</a></li>
  <li class="list-group-item"><a href="<?php echo base_url()?>employee/addEmployeeView">Add Employee</a></li> 
</ul>
    </div>
    <div class="col-sm">
<ul class="list-group">
  <li class="list-group-item"><b>Employee</b></li>
  <li class="list-group-item"><a href="<?php echo base_url()?>upload_controller/view_job">View Jobs</a></li>
  <li class="list-group-item"><a href="<?php echo base_url()?>upload_controller">Add Jobs</a></li> 
</ul>
    </div>
    <div class="col-sm">
     
    </div>
  </div>
</div>