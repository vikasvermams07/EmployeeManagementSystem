<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if(!$_SESSION['username']){
    
    redirect('my_controller','refresh');
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dash View</title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
    <!--Navigation Bar-->
   <?php 
   $this->load->view('dash/navi/navi_view');

   //list view
   $this->load->view('dash/list_view');
   
   ?>



</body>
</html>