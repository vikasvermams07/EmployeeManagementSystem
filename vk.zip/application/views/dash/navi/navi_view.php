<nav class="navbar navbar-expand-lg navbar-light bg-light">


  <a class="navbar-brand" href="#"><?php echo $_SESSION['username']?></a>
  <div >
  <a href="<?php echo base_url()?>my_controller/logout" class="btn btn-link ">LogOut</a>
  </div>
</nav>