<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class upload_model extends CI_Model {

    public function InsertJob($jobname){
        
        $this->db->insert('jobes', $jobname);
        
    }

    

}



?>