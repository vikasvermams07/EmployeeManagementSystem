<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class employee_model extends CI_Model {

    public function addEmployee($data){

        
        $this->db->insert('employee', $data);
        
    }

}

?>