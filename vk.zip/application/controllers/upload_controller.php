

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class upload_controller extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
      
      $this->load->model('upload_model');
      
    }
    
    public function index()
    {
        
        $this->load->view('dash/upload');
        
    }

    public function upload_jobinfo(){

        if($this->input->post("upload")){

            $job=$this->input->post("j_name");
            
            $jobinfo=array('j_name'=>$job);

            $this->upload_model->InsertJob($jobinfo);

          
          redirect('upload_controller/view_job','refresh');
          
        }
    }


    public function view_job()
    {
        

        $this->load->view('dash/job_view');
        
    }

    public function updatejobView(){
        
        $this->load->view('dash/updateJob');
        
    }

    public function updatejobsname(){

        if($this->input->post("update")){

            $jname=$this->input->post("update_name");
            $id=$this->input->post("jid");

            $data=array('j_name'=>$jname);

           
           $this->db->where('id', $id);
           
           $this->db->update('jobes', $data);

           
           redirect('upload_controller/view_job','refresh');
           
           
           

        }
    }

    public function deleteJob($id){

        

        $this->db->where('id', $id);
        
         $this->db->delete('jobes');

         redirect('upload_controller/view_job','refresh');
        
    }



}


?>