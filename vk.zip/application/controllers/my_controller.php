<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class my_controller extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        
        $this->load->model('User');
        
    }
    
    
    public function index()
    {
        $this->load->view('my_view');
    }
public function register(){
    $this->load->view('register');
}
    public function myfunction(){

  if($this->input->post('mybtn')){
        $username=$this->input->post('uname');
        $pass=md5($this->input->post('pass'));
        $result=array('username'=>$username,'password'=>$pass);

        $user_info=$this->db->get_where("users",array('u_name'=>$result['username']));

        foreach($user_info->result() as $row){

            if($result['username']==$row->u_name && $result['password']==$row->u_pass){

             $_SESSION['username']=$result['username'];
             redirect('dash_controller','refresh');
             
            }
            else{
                echo "<script>alert('username or password in wrong');</script>";
                
                redirect('my_controller','refresh');
                
            }
        }

     }else{
        
     redirect('my_controller','refresh');
    }
 }

 public function register_pocess(){
     if($this->input->post('register')){
         $email=$this->input->post('email');
         $unam=$this->input->post('uname');
         $pass=md5($this->input->post('pass'));

         $info=array('u_email'=>$email,'u_name'=>$unam,'u_pass'=>$pass);

         $this->User->insert($info);

         
         redirect('my_controller','refresh');
         
         
     }else{
         
         redirect('my_controller','refresh');
         
     }
 }

 public function logout(){
     
     session_destroy();
     
     redirect('my_controller','refresh');
     
 }


}
?>