<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class dash_controller extends CI_Controller {

    public function index()
    {
        
        $this->load->view('dash/dash_view');
        
    }

}



?>