
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class employee extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        
        $this->load->model('employee_model');
        
    }
    

    public function index()
    {
        
        $this->load->view('view_employee');
        
    }

    public function addEmployeeView(){

        
        $this->load->view('dash/addemployee');
        
    }

    public function EmployeeView(){

        
        $this->load->view('dash/viewmployee');
        
    }

    public function EmployeeDetails(){

        
        $this->load->view('dash/detalisemployee');
        
    }

    public function EmployeeUpdate(){

        
        $this->load->view('dash/updateemployee');
        
    }

    public function employeeUpdateinfo(){



        if($this->input->post('updateemployee')){

            $e_name=$this->input->post('e_name');
            $e_email=$this->input->post('e_email');
            $e_number=$this->input->post('e_number');
            $e_job=$this->input->post('e_job');

            $data=array('e_name'=>$e_name,'e_email'=>$e_email,'e_number'=>$e_number,'e_job'=>$e_job);
           $id=$this->uri->segment(3);
          
           
           $this->db->where('e_id', $id);
           
           $this->db->update('employee',$data);
            redirect('employee/EmployeeView','refresh');
        }
        }

        public function deleteEmployee($id){
            
            $this->db->where('e_id', $id);
            
            $this->db->delete('employee');
            redirect('employee/EmployeeView','refresh');
        }

    public function employeeinfo(){

        if($this->input->post('addemployee')){

            $e_name=$this->input->post('e_name');
            $e_email=$this->input->post('e_email');
            $e_number=$this->input->post('e_number');
            $e_job=$this->input->post('e_job');

            $data=array('e_name'=>$e_name,'e_email'=>$e_email,'e_number'=>$e_number,'e_job'=>$e_job);
            
            $this->employee_model->addEmployee($data);
            
            redirect('employee/EmployeeView','refresh');
            
        }
    }

}

/* End of file Controllername.php */

?>